

Visit the website on:

https://jhamohan.github.io/SN_Ethereum/







Contract Address: 0xe22E4E1111192a4bD3D7443897326362DeC07899


Follow below link to View the contract on EtherSacn Ropsten Testnet:
https://ropsten.etherscan.io/address/0xe22E4E1111192a4bD3D7443897326362DeC07899









//To help for meta mask
https://medium.com/metamas/https-medium-com-metamask-breaking-change-injecting-web3-7722797916a8


to deploy on Ropsten Testnet Network

https://medium.com/coinmonks/deploy-your-smart-contract-directly-from-truffle-with-infura-ba1e1f1d40c2
